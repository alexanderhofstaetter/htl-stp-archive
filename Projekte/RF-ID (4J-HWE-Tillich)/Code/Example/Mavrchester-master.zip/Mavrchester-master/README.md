mavrchester
===========

Atmel AVR C code for Manchester Encoding. 

Blog post: http://thecodeinn.blogspot.co.at/2014/06/avr-manchester-encoding.html
